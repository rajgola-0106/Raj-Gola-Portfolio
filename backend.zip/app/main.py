from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .db import init_db
from .routers import auth, users, events, elections, blog, admin, media

app = FastAPI(title="Turing Society API - FastAPI Scaffold")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    init_db()

# include routers
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(users.router, prefix="/api/users", tags=["users"])
app.include_router(events.router, prefix="/api/events", tags=["events"])
app.include_router(elections.router, prefix="/api/elections", tags=["elections"])
app.include_router(blog.router, prefix="/api/blog", tags=["blog"])
app.include_router(admin.router, prefix="/api/admin", tags=["admin"])
app.include_router(media.router, prefix="/api/media", tags=["media"])
