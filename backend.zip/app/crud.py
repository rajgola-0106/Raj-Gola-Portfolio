from sqlmodel import select
from .models import User, Event, EventRegistration, Election, Candidate, Vote, BlogPost
from .db import get_session
from typing import Optional

def get_user_by_email(session, email: str) -> Optional[User]:
    return session.exec(select(User).where(User.email == email)).first()

def create_user(session, user: User):
    session.add(user)
    session.commit()
    session.refresh(user)
    return user

def create_event(session, event: Event):
    session.add(event)
    session.commit()
    session.refresh(event)
    return event

def list_events(session):
    return session.exec(select(Event)).all()

def register_user_to_event(session, user_id: int, event_id: int):
    reg = EventRegistration(user_id=user_id, event_id=event_id)
    session.add(reg)
    session.commit()
    session.refresh(reg)
    return reg

def create_election(session, election: Election):
    session.add(election)
    session.commit()
    session.refresh(election)
    return election

def add_candidate(session, candidate: Candidate):
    session.add(candidate)
    session.commit()
    session.refresh(candidate)
    return candidate

def cast_vote(session, vote: Vote):
    # naive: create vote and increment candidate count
    session.add(vote)
    candidate = session.get(Candidate, vote.candidate_id)
    if candidate:
        candidate.votes_count += 1
    session.commit()
    session.refresh(vote)
    return vote
