from typing import Optional
from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime
from enum import Enum

class Role(str, Enum):
    student = "student"
    faculty = "faculty"
    admin = "admin"

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    email: str = Field(index=True, unique=True)
    full_name: Optional[str]
    hashed_password: Optional[str]
    role: Role = Field(default=Role.student)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # relationships
    registrations: list["EventRegistration"] = Relationship(back_populates="user")
    votes: list["Vote"] = Relationship(back_populates="user")

class Event(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: Optional[str]
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    location: Optional[str]
    capacity: Optional[int]
    created_at: datetime = Field(default_factory=datetime.utcnow)

    registrations: list["EventRegistration"] = Relationship(back_populates="event")

class EventRegistration(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id")
    event_id: int = Field(foreign_key="event.id")
    registered_at: datetime = Field(default_factory=datetime.utcnow)

    user: Optional[User] = Relationship(back_populates="registrations")
    event: Optional[Event] = Relationship(back_populates="registrations")

class BlogPost(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    slug: Optional[str]
    content: Optional[str]
    author_id: Optional[int] = Field(foreign_key="user.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Election(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    description: Optional[str]
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    is_active: bool = Field(default=False)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    candidates: list["Candidate"] = Relationship(back_populates="election")

class Candidate(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    election_id: int = Field(foreign_key="election.id")
    user_id: int = Field(foreign_key="user.id")
    position: Optional[str]
    manifesto: Optional[str]
    votes_count: int = Field(default=0)

    election: Optional[Election] = Relationship(back_populates="candidates")

class Vote(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    election_id: int = Field(foreign_key="election.id")
    candidate_id: int = Field(foreign_key="candidate.id")
    user_id: int = Field(foreign_key="user.id")
    cast_at: datetime = Field(default_factory=datetime.utcnow)

    user: Optional[User] = Relationship(back_populates="votes")
