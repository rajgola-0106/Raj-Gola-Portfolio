from fastapi import APIRouter, Depends, HTTPException
from ..schemas import ElectionCreate, CandidateCreate, VoteCreate
from ..db import get_session
from sqlmodel import Session, select
from ..models import Election, Candidate, Vote
from datetime import datetime

router = APIRouter()

@router.post("/", response_model=dict)
def create_election(payload: ElectionCreate, session: Session = Depends(get_session)):
    election = Election(**payload.dict())
    session.add(election)
    session.commit()
    session.refresh(election)
    return {"id": election.id, "name": election.name}

@router.post("/candidate", response_model=dict)
def nominate(payload: CandidateCreate, session: Session = Depends(get_session)):
    candidate = Candidate(**payload.dict())
    session.add(candidate)
    session.commit()
    session.refresh(candidate)
    return {"id": candidate.id, "position": candidate.position}

@router.post("/vote", response_model=dict)
def vote(payload: VoteCreate, user_id: int, session: Session = Depends(get_session)):
    # simple checks (in production: verify JWT & that user hasn't voted)
    vote = Vote(election_id=payload.election_id, candidate_id=payload.candidate_id, user_id=user_id)
    session.add(vote)
    candidate = session.get(Candidate, payload.candidate_id)
    if candidate:
        candidate.votes_count += 1
    session.commit()
    return {"status": "ok"}
