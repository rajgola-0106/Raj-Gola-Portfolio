from fastapi import APIRouter, Depends, HTTPException
from ..schemas import UserCreate, UserRead
from ..db import get_session
from sqlmodel import Session, select
from ..models import User

router = APIRouter()

@router.post("/", response_model=UserRead)
def create_user(payload: UserCreate, session: Session = Depends(get_session)):
    user = User(email=payload.email, full_name=payload.full_name, hashed_password=payload.password, role=payload.role)
    session.add(user)
    session.commit()
    session.refresh(user)
    return user

@router.get("/", response_model=list[UserRead])
def list_users(session: Session = Depends(get_session)):
    return session.exec(select(User)).all()
