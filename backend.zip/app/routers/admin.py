from fastapi import APIRouter, Depends
from ..db import get_session
from sqlmodel import Session, select
from ..models import User, Event, Election

router = APIRouter()

@router.get("/stats")
def stats(session: Session = Depends(get_session)):
    users = session.exec(select(User)).all()
    events = session.exec(select(Event)).all()
    elections = session.exec(select(Election)).all()
    return {
        "users_count": len(users),
        "events_count": len(events),
        "elections_count": len(elections)
    }
