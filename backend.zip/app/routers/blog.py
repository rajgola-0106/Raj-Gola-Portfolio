from fastapi import APIRouter, Depends
from ..db import get_session
from sqlmodel import Session, select
from ..models import BlogPost

router = APIRouter()

@router.post("/", response_model=dict)
def create_post(title: str, content: str, author_id: int, session: Session = Depends(get_session)):
    post = BlogPost(title=title, content=content, author_id=author_id)
    session.add(post)
    session.commit()
    session.refresh(post)
    return {"id": post.id, "title": post.title}

@router.get("/", response_model=list[dict])
def list_posts(session: Session = Depends(get_session)):
    posts = session.exec(select(BlogPost)).all()
    return [{"id": p.id, "title": p.title, "created_at": p.created_at} for p in posts]
