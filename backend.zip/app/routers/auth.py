from fastapi import APIRouter, Depends, HTTPException, status
from ..schemas import UserCreate, Token
from .. import crud, models
from ..db import engine, get_session
from sqlmodel import Session
from passlib.context import CryptContext
from jose import jwt
import os
from fastapi import Body

router = APIRouter()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-secret")

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def get_password_hash(password):
    return pwd_context.hash(password)

@router.post("/register", response_model=Token)
def register(payload: UserCreate, session: Session = Depends(get_session)):
    existing = crud.get_user_by_email(session, payload.email)
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user = models.User(email=payload.email, full_name=payload.full_name, hashed_password=get_password_hash(payload.password), role=payload.role)
    session.add(user)
    session.commit()
    session.refresh(user)
    token = jwt.encode({"sub": user.email}, SECRET_KEY, algorithm="HS256")
    return {"access_token": token, "token_type": "bearer"}

@router.post("/login", response_model=Token)
def login(email: str = Body(...), password: str = Body(...), session: Session = Depends(get_session)):
    user = crud.get_user_by_email(session, email)
    if not user or not verify_password(password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = jwt.encode({"sub": user.email}, SECRET_KEY, algorithm="HS256")
    return {"access_token": token, "token_type": "bearer"}
