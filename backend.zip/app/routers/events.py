from fastapi import APIRouter, Depends, HTTPException
from ..schemas import EventCreate, EventRead
from ..db import get_session
from sqlmodel import Session, select
from ..models import Event
from datetime import datetime

router = APIRouter()

@router.post("/", response_model=EventRead)
def create_event(payload: EventCreate, session: Session = Depends(get_session)):
    event = Event(**payload.dict())
    session.add(event)
    session.commit()
    session.refresh(event)
    return event

@router.get("/", response_model=list[EventRead])
def list_events(session: Session = Depends(get_session)):
    return session.exec(select(Event)).all()

@router.post("/{event_id}/register")
def register(event_id: int, user_id: int, session: Session = Depends(get_session)):
    from ..crud import register_user_to_event
    return register_user_to_event(session, user_id=user_id, event_id=event_id)
