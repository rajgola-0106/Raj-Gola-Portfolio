from typing import Optional, List
from pydantic import BaseModel, EmailStr
from datetime import datetime
from .models import Role

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserCreate(BaseModel):
    email: EmailStr
    full_name: Optional[str]
    password: str
    role: Role = Role.student

class UserRead(BaseModel):
    id: int
    email: EmailStr
    full_name: Optional[str]
    role: Role

    class Config:
        orm_mode = True

class EventCreate(BaseModel):
    title: str
    description: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    location: Optional[str] = None
    capacity: Optional[int] = None

class EventRead(BaseModel):
    id: int
    title: str
    description: Optional[str]
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    location: Optional[str]
    capacity: Optional[int]

    class Config:
        orm_mode = True

class ElectionCreate(BaseModel):
    name: str
    description: Optional[str]
    start_time: Optional[datetime]
    end_time: Optional[datetime]

class CandidateCreate(BaseModel):
    election_id: int
    user_id: int
    position: Optional[str]
    manifesto: Optional[str]

class VoteCreate(BaseModel):
    election_id: int
    candidate_id: int
