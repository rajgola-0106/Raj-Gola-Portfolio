# Turing Society - FastAPI Backend Scaffold
This scaffold contains a FastAPI project template implementing APIs for:
- Authentication (JWT + email/OTP stub)
- Users (students, faculty, roles)
- Events (CRUD, registration, calendar endpoints)
- Elections (nomination, voting, results)
- Blog & Gallery endpoints
- Admin utilities and analytics endpoints

This is a scaffold to jumpstart development; you'll need to wire in real email/SMS services, persistent storage, and production config.

## Run locally (development)
1. Create a virtualenv: `python -m venv .venv && source .venv/bin/activate`
2. Install: `pip install -r requirements.txt`
3. Run: `uvicorn app.main:app --reload --port 8000`
